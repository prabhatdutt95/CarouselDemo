import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'CarouselDemo';

  cars: any[]=[{model:"Maruti", year:"2012"},
              {model:"Honda", year:"2013"},
              {model:"Fiat", year:"2014"},
              {model:"Hyundai", year:"2013"},
              {model:"Ferrari", year:"2017"},
              {model:"Lamborgini", year:"2018"},
              {model:"Maruti", year:"2012"},
              {model:"Honda", year:"2013"},
              {model:"Fiat", year:"2014"},
              {model:"Hyundai", year:"2013"},
              {model:"Ferrari", year:"2017"},
              {model:"Lamborgini", year:"2018"}];
  //"Car1","Car2","Car3","Car4","Car5","Car6","Car7",
  display: boolean = false;

  selectCar(){
    console.log("Button Pressed");
  }
  showDialog(){
    if(this.display == false)
      this.display=true;
    else
      this.display=false;
  }
}
